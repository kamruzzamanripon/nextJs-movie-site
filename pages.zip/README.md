# NextJs Movie Template

## API Fetch From -

##API Setup
reName .env.example file like as .env and put your TMDB Api key.

[Link](https://www.themoviedb.org/)

## Site Screen Shot

![This is a alt text.](/public/screen_shot.jpg)

## Install and Run

1. npm install
2. API Setup reName .env.example file like as .env.local and put your TMDB Api key.
3. npm run dev
