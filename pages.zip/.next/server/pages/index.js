"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 114:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: external "react-responsive-carousel"
const external_react_responsive_carousel_namespaceObject = require("react-responsive-carousel");
;// CONCATENATED MODULE: ./components/Carousel.js



 // requires a loader
const HCarousel = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative mt-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute w-full bg-gradient-to-t from-gray-100 to-transparent bottom-0 z-20"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_responsive_carousel_namespaceObject.Carousel, {
                autoPlay: true,
                infiniteLoop: true,
                showStatus: false,
                showIndicators: false,
                showThumbs: false,
                interval: 5000,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "carousel-slider",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: "h-65",
                            loading: "lazy",
                            src: "https://images.unsplash.com/photo-1532568547949-a09f1afe4d1b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: "h-65",
                            loading: "lazy",
                            src: "https://images.unsplash.com/photo-1510827220565-c6a086ff31c8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: "h-65",
                            loading: "lazy",
                            src: "https://images.unsplash.com/photo-1585647347384-2593bc35786b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
                            alt: ""
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const Carousel = (HCarousel);

;// CONCATENATED MODULE: external "@heroicons/react/outline"
const outline_namespaceObject = require("@heroicons/react/outline");
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
;// CONCATENATED MODULE: ./components/HeaderItem.js


const HeaderItem = ({ Icon , title  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center cursor-pointer group w-12 sm:w-20 hover:text-white",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                className: "h-8 mb-1 group-hover:animate-bounce"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "tracking-widest opacity-0 group-hover:opacity-100",
                children: title
            })
        ]
    }));
};
/* harmony default export */ const components_HeaderItem = (HeaderItem);

;// CONCATENATED MODULE: ./public/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.e2579602.png","height":420,"width":652,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAoklEQVR42mNoKk0rLYx2/5HsYfi/JsZuSmuq05QsX5P/ZXGeP9oqskoZ/G2tEm1kRL96qMj/CDJV+5/hrPXfX0P+h6uCyNcQB5tEBhjI9nEwcdFW/VXqZ/yrNMTFGC6R6u4cF2CksdvLSPNMnKX2/xIPg/+B5jpnIi11d2V6usQxJNhYVyXbmv3Pttf/3+BlNKclwHROsbvZ/0wHy/+ptjaVAAAdOh+etfydAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/Header.js






function Header() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: "flex flex-col sm:flex-row m-5 justify-between items-center h-auto",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-grow justify-evenly max-w-2xl",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_HeaderItem, {
                        title: "HOME",
                        Icon: outline_namespaceObject.HomeIcon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_HeaderItem, {
                        title: "HOME",
                        Icon: outline_namespaceObject.LightningBoltIcon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_HeaderItem, {
                        title: "HOME",
                        Icon: outline_namespaceObject.BadgeCheckIcon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_HeaderItem, {
                        title: "HOME",
                        Icon: outline_namespaceObject.CollectionIcon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_HeaderItem, {
                        title: "HOME",
                        Icon: outline_namespaceObject.SearchIcon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_HeaderItem, {
                        title: "HOME",
                        Icon: outline_namespaceObject.UserIcon
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                className: "object-contain",
                src: logo,
                width: 200,
                height: 100
            })
        ]
    }));
}
/* harmony default export */ const components_Header = (Header);

;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
;// CONCATENATED MODULE: ./utils/requests.js
const API_KEY = process.env.API_KEY;
// eslint-disable-next-line import/no-anonymous-default-export
/* harmony default export */ const requests = ({
    fetchTrending: {
        title: "Trending",
        url: `/trending/all/week?api_key=${API_KEY}&language=en-US`
    },
    fetchTopRated: {
        title: "Top Rated",
        url: `/movie/top_rated?api_key=${API_KEY}&language=en-US`
    },
    fetchActionMovies: {
        title: "Action",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=28`
    },
    fetchComedyMovies: {
        title: "Comedy",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=35`
    },
    fetchHorrorMovies: {
        title: "Horror",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=27`
    },
    fetchRomanceMovies: {
        title: "Romance",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=10749`
    },
    fetchMystery: {
        title: "Mystery",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=9648`
    },
    fetchSciFi: {
        title: "Sci-Fi",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=878`
    },
    fetchWestern: {
        title: "Western",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=37`
    },
    fetchAnimation: {
        title: "Animation",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=16`
    },
    fetchTV: {
        title: "TV Movie",
        url: `/discover/movie?api_key=${API_KEY}&with_genres=10770`
    }
});

;// CONCATENATED MODULE: ./components/Nav.js




const Nav = ()=>{
    const router = (0,router_namespaceObject.useRouter)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex px-10 sm:px-20 text-2xl whitespace-nowrap space-x-10 sm:space-x-20 overflow-x-scroll scrollbar-hide",
                children: Object.entries(requests).map(([key, { title , url  }])=>/*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "cursor-pointer transition duration-100 transform hover:scale-125 hover:text-white active:text-red-500",
                        onClick: ()=>router.push(`/?genre=${key}`)
                        ,
                        children: title
                    }, key)
                )
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute top-0 right-0 bg-gradient-to-l from-[#06202A] h-10 w-1/12"
            })
        ]
    }));
};
/* harmony default export */ const components_Nav = (Nav);

;// CONCATENATED MODULE: external "react-flip-move"
const external_react_flip_move_namespaceObject = require("react-flip-move");
var external_react_flip_move_default = /*#__PURE__*/__webpack_require__.n(external_react_flip_move_namespaceObject);
;// CONCATENATED MODULE: ./components/Thumbnail.js




// eslint-disable-next-line react/display-name
const Thumbnail = /*#__PURE__*/ (0,external_react_.forwardRef)(({ result  }, ref)=>{
    const BASE_URL = "https://image.tmdb.org/t/p/original/";
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        ref: ref,
        className: "mx-10 my-5 group cursor-pointer transition duration-200 ease-in transform sm:hover:scale-105 hover:z-50",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                layout: "responsive",
                src: `${BASE_URL}${result.backdrop_path || result.poster_path}` || `${BASE_URL}${result.poster_path}`,
                height: 1080,
                width: 1920
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "truncate max-w-md",
                        children: result.overview
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "mt-1 text-2xl text-white transition-all duration-100 ease-out group-hover:font-bold",
                        children: result.title || result.original_name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "flex items-center opacity-0 group-hover:opacity-100",
                        children: [
                            result.media_type && `${result.media_type} .`,
                            " ",
                            result.release_date || result.first_air_date,
                            " .",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx(outline_namespaceObject.ThumbUpIcon, {
                                className: "h-5 mx-2"
                            }),
                            " ",
                            result.vote_count
                        ]
                    })
                ]
            })
        ]
    }));
});
/* harmony default export */ const components_Thumbnail = (Thumbnail);

;// CONCATENATED MODULE: ./components/Results.js




const Results = ({ results  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx((external_react_flip_move_default()), {
        className: "px-5 my-10 sm:grid md:grid-cols-2 xl:grid-cols-3 3xl:flex flex-wrap justify-center",
        children: results.map((result)=>/*#__PURE__*/ jsx_runtime_.jsx(components_Thumbnail, {
                result: result
            }, result.id)
        )
    }));
};
/* harmony default export */ const components_Results = (Results);

;// CONCATENATED MODULE: ./pages/index.js







function Home({ results  }) {
    //console.log(results)
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Hulu 2.0"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Nav, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Carousel, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Results, {
                results: results
            })
        ]
    }));
};
async function getServerSideProps(context) {
    const genre = context.query.genre;
    const request = await fetch(`https://api.themoviedb.org/3${requests[genre]?.url || requests.fetchTrending.url}`).then((res)=>res.json()
    );
    return {
        props: {
            results: request.results
        }
    };
}


/***/ }),

/***/ 28:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675], () => (__webpack_exec__(114)));
module.exports = __webpack_exports__;

})();